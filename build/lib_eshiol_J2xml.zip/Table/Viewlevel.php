<?php
/**
 * @package     Joomla.Libraries
 * @subpackage  eshiol.J2XML
 *
 * @version     __DEPLOY_VERSION__
 * @since       15.3.248
 *
 * @author      Helios Ciancio <info (at) eshiol (dot) it>
 * @link        https://www.eshiol.it
 * @copyright   Copyright (C) 2010 - 2023 Helios Ciancio. All Rights Reserved
 * @license     http://www.gnu.org/licenses/gpl-3.0.html GNU/GPL v3
 * J2XML is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License
 * or other free or open source software licenses.
 */
namespace eshiol\J2xml\Table;
defined('JPATH_PLATFORM') or define('JPATH_PLATFORM', JPATH_LIBRARIES);

use eshiol\J2xml\Table\Table;
\JLoader::import('eshiol.J2xml.Table.Table');

/**
 *
 * Viewlevel Table
 *
 */
class Viewlevel extends Table
{

	/**
	 * Constructor
	 *
	 * @param \JDatabaseDriver $db
	 *			A database connector object
	 *
	 * @since 15.3.248
	 */
	public function __construct (\JDatabaseDriver $db)
	{
		\Joomla\CMS\Log\Log::add(new \Joomla\CMS\Log\LogEntry(__METHOD__, \Joomla\CMS\Log\Log::DEBUG, 'com_j2xml'));

		parent::__construct('#__viewlevels', 'id', $db);
	}

	/**
	 * Export item list to xml
	 *
	 * @access public
	 */
	function toXML ($mapKeysToText = false)
	{
		\Joomla\CMS\Log\Log::add(new \Joomla\CMS\Log\LogEntry(__METHOD__, \Joomla\CMS\Log\Log::DEBUG, 'com_j2xml'));

		$this->_excluded = array_merge($this->_excluded, array(
				'rules'
		));

		$version = new \Joomla\CMS\Version();
		$serverType = $version->isCompatible('3.5') ? $this->_db->getServerType() : 'mysql';

		if ($serverType === 'postgresql')
		{
			$this->_aliases['rule'] = '
				WITH RECURSIVE usergroups(id, title, parent_id, depth, path) AS (
				  SELECT tn.id, tn.title, tn.parent_id, 1::INT AS depth, tn.title::TEXT AS path
				  FROM #__usergroups AS tn
				  WHERE tn.parent_id = 0
				UNION ALL
				  SELECT c.id, c.title, c.parent_id, p.depth + 1 AS depth,
						(p.path || \'","\' || c.title) AS path
				  FROM usergroups AS p, #__usergroups AS c
				  WHERE c.parent_id = p.id
				)
				SELECT (\'["\' || path || \'"]\') FROM usergroups WHERE id IN ' . str_replace(array(
					'[',
					']'
			), array(
					'(',
					')'
			), $this->rules);
		}
		else
		{
			$this->_aliases['rule'] = (string) $this->_db->getQuery(true)
				->select($this->_db->quoteName('title'))
				->from($this->_db->quoteName('#__j2xml_usergroups', 'g'))
				->where(
					$this->_db->quoteName('g.id') . ' IN ' . str_replace(array(
							'[',
							']'
					), array(
							'(',
							')'
					), $this->rules));
		}

		return parent::toXML($mapKeysToText);
	}

	/**
	 * Import data
	 *
	 * @param \SimpleXMLElement $xml
	 *			xml
	 * @param \JRegistry $params
	 *			@option int 'viewlevels' 0: No | 1: Yes, if not exists | 2:
	 *			Yes, overwrite if exists
	 *			@option string 'context'
	 *
	 * @throws
	 * @return void
	 * @access public
	 *
	 * @since 18.8.310
	 */
	public static function import ($xml, &$params)
	{
		\Joomla\CMS\Log\Log::add(new \Joomla\CMS\Log\LogEntry(__METHOD__, \Joomla\CMS\Log\Log::DEBUG, 'com_j2xml'));

		$import_viewlevels = $params->get('viewlevels', 1);
		if ($import_viewlevels == 0)
		{
			return;
		}

		$db = \Joomla\CMS\Factory::getDbo();
		foreach ($xml->xpath("//j2xml/viewlevel[not(title = '')]") as $record)
		{
			self::prepareData($record, $data, $params);

			$id = $data['id'];

			$query = $db->getQuery(true)
				->select(array(
					$db->quoteName('id'),
					$db->quoteName('title')
			))
				->from($db->quoteName('#__viewlevels'))
				->where($db->quoteName('title') . ' = ' . $db->quote($data['title']));
			$item = $db->setQuery($query)->loadObject();

			if (!$item || ($import_viewlevels == 2))
			{
				$table = new \eshiol\J2xml\Table\Viewlevel($db);
				if (!$item)
				{
					$data['id'] = null;
				}
				else
				{
					$data['id'] = $item->id;
					$table->load($data['id']);
				}

				// Add rules to the viewlevel data.
				$rules_id = array();
				if (isset($data['rule']))
				{
					$rules_id[] = $data['rule'];
					unset($data['rule']);
				}
				if (isset($data['rulelist']))
				{
					foreach ($data['rulelist']['rule'] as $v)
					{
						$rules_id[] = $v;
					}
					unset($data['rulelist']);
				}

				for ($i = 0; $i < count($rules_id); $i ++)
				{
					$usergroup = parent::getUsergroupId($rules_id[$i]);
					if ($usergroup !== null)
					{
						$rules_id[$i] = $usergroup;
					}
					else
					{
						$groups = json_decode($rules_id[$i]);
						$g = array();
						$id = 0;

						for ($j = 0; $j < count($groups); $j ++)
						{
							$g[] = $groups[$j];
							$group = json_encode($g, JSON_NUMERIC_CHECK);
							$usergroup = parent::getUsergroupId($group);
							if ($usergroup !== null)
							{
								$id = $usergroup;
							}
							else // import usergroup
							{
								$u = new \Joomla\CMS\Table\Usergroup($db); // \Joomla\CMS\Table\Table::getInstance('Usergroup');
								$u->save(array(
										'title' => $groups[$j],
										'parent_id' => $id
								));
								$id = $u->id;
								\Joomla\CMS\Log\Log::add(new \Joomla\CMS\Log\LogEntry(\Joomla\CMS\Language\Text::sprintf('LIB_J2XML_MSG_USERGROUP_IMPORTED', $groups[$j]), \Joomla\CMS\Log\Log::INFO, 'lib_j2xml'));
							}
						}
						$rules_id[$i] = $id;
					}
				}
				$data['rules'] = json_encode($rules_id, JSON_NUMERIC_CHECK);

				if ($table->save($data))
				{
					\Joomla\CMS\Log\Log::add(new \Joomla\CMS\Log\LogEntry(\Joomla\CMS\Language\Text::sprintf('LIB_J2XML_MSG_VIEWLEVEL_IMPORTED', $table->title), \Joomla\CMS\Log\Log::INFO, 'lib_j2xml'));
				}
				else
				{
					\Joomla\CMS\Log\Log::add(new \Joomla\CMS\Log\LogEntry(\Joomla\CMS\Language\Text::sprintf('LIB_J2XML_MSG_VIEWLEVEL_NOT_IMPORTED', $data['title'], $table->getError()), \Joomla\CMS\Log\Log::ERROR, 'lib_j2xml'));
				}

				$table = null;
			}
		}
	}

	/**
	 * Export data
	 *
	 * @param int $id
	 *			the id of the item to be exported
	 * @param \SimpleXMLElement $xml
	 *			xml
	 * @param array $options
	 *
	 * @throws
	 * @return void
	 * @access public
	 *
	 * @since 18.8.310
	 */
	public static function export ($id, &$xml, $options)
	{
		\Joomla\CMS\Log\Log::add(new \Joomla\CMS\Log\LogEntry(__METHOD__, \Joomla\CMS\Log\Log::DEBUG, 'com_j2xml'));

		if ($xml->xpath("//j2xml/viewlevel/id[text() = '" . $id . "']"))
		{
			return;
		}

		$db = \Joomla\CMS\Factory::getDbo();
		$item = new Viewlevel($db);
		if (!$item->load($id))
		{
			return;
		}

		$doc = dom_import_simplexml($xml)->ownerDocument;
		$fragment = $doc->createDocumentFragment();

		$fragment->appendXML($item->toXML());
		$doc->documentElement->appendChild($fragment);
	}
}
